// async-patterns.js
// Demonstrates and compares three async patterns in Node.js:
// callbacks, Promises, and async/await -- all doing the same
// simulated "fetch user data" task.

function fetchUserCallback(id, callback) {
  setTimeout(() => {
    if (id <= 0) return callback(new Error('Invalid user id'));
    callback(null, { id, name: `User${id}` });
  }, 200);
}

function fetchUserPromise(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (id <= 0) return reject(new Error('Invalid user id'));
      resolve({ id, name: `User${id}` });
    }, 200);
  });
}

async function fetchUserAsyncAwait(id) {
  const user = await fetchUserPromise(id);
  return user;
}

function runCallbackStyle() {
  console.log('\n--- Callback style ---');
  fetchUserCallback(1, (err, user) => {
    if (err) return console.error('Callback error:', err.message);
    console.log('Callback result:', user);
  });
}

function runPromiseStyle() {
  console.log('\n--- Promise style ---');
  fetchUserPromise(2)
    .then((user) => console.log('Promise result:', user))
    .catch((err) => console.error('Promise error:', err.message));
}

async function runAsyncAwaitStyle() {
  console.log('\n--- Async/Await style ---');
  try {
    const user = await fetchUserAsyncAwait(3);
    console.log('Async/Await result:', user);
  } catch (err) {
    console.error('Async/Await error:', err.message);
  }
}

async function main() {
  runCallbackStyle();
  runPromiseStyle();
  await runAsyncAwaitStyle();

  // Demonstrating Promise.all for concurrent requests
  console.log('\n--- Promise.all (concurrent fetch) ---');
  const users = await Promise.all([
    fetchUserPromise(4),
    fetchUserPromise(5),
    fetchUserPromise(6),
  ]);
  console.log('All users fetched concurrently:', users);
}

main();
