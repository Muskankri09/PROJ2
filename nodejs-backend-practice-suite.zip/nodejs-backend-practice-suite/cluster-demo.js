// cluster-demo.js
// Demonstrates the Node.js Cluster module to simulate multi-core
// load distribution across worker processes, with a simple HTTP
// server that reports which worker handled the request.

const cluster = require('cluster');
const http = require('http');
const os = require('os');

const PORT = 3000;

if (cluster.isPrimary) {
  const numCPUs = Math.min(os.cpus().length, 4); // cap for demo purposes
  console.log(`Primary process ${process.pid} is running`);
  console.log(`Forking ${numCPUs} workers...`);

  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }

  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker ${worker.process.pid} died. Forking a replacement...`);
    cluster.fork();
  });
} else {
  // Each worker runs its own HTTP server instance; the OS load-balances
  // incoming connections across all workers.
  http
    .createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(`Handled by worker ${process.pid}\n`);
    })
    .listen(PORT);

  console.log(`Worker ${process.pid} started and listening on port ${PORT}`);
}
