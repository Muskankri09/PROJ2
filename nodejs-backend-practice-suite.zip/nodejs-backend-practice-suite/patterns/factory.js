// factory.js
// Factory pattern: centralizes object creation logic so the caller
// doesn't need to know the concrete class being instantiated.

class EmailNotification {
  send(message) {
    console.log(`Sending EMAIL: ${message}`);
  }
}

class SMSNotification {
  send(message) {
    console.log(`Sending SMS: ${message}`);
  }
}

class PushNotification {
  send(message) {
    console.log(`Sending PUSH notification: ${message}`);
  }
}

class NotificationFactory {
  static create(type) {
    switch (type) {
      case 'email':
        return new EmailNotification();
      case 'sms':
        return new SMSNotification();
      case 'push':
        return new PushNotification();
      default:
        throw new Error(`Unknown notification type: ${type}`);
    }
  }
}

module.exports = NotificationFactory;
