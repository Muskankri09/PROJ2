// observer.js
// Observer pattern: subjects notify a list of subscribed observers
// whenever their state changes. Implemented using Node's built-in
// EventEmitter, the same mechanism Node uses internally for streams,
// HTTP servers, etc.

const EventEmitter = require('events');

class OrderTracker extends EventEmitter {
  placeOrder(orderId) {
    console.log(`Order ${orderId} placed.`);
    this.emit('orderPlaced', orderId);
  }

  shipOrder(orderId) {
    console.log(`Order ${orderId} shipped.`);
    this.emit('orderShipped', orderId);
  }
}

function createSubscribers(tracker) {
  tracker.on('orderPlaced', (orderId) => {
    console.log(`[Email Service] Confirmation email sent for order ${orderId}`);
  });

  tracker.on('orderPlaced', (orderId) => {
    console.log(`[Inventory Service] Stock reserved for order ${orderId}`);
  });

  tracker.on('orderShipped', (orderId) => {
    console.log(`[SMS Service] Shipping alert sent for order ${orderId}`);
  });
}

module.exports = { OrderTracker, createSubscribers };
