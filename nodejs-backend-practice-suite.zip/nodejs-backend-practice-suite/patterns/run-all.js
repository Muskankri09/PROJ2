// run-all.js
// Demonstrates Singleton, Factory, and Observer patterns together.

const DatabaseConnection = require('./singleton.js');
const NotificationFactory = require('./factory.js');
const { OrderTracker, createSubscribers } = require('./observer.js');

console.log('=== Singleton Pattern ===');
const db1 = new DatabaseConnection();
const db2 = new DatabaseConnection();
db1.query('SELECT * FROM users');
console.log('db1 === db2 (same instance)?', db1 === db2);

console.log('\n=== Factory Pattern ===');
const emailNotifier = NotificationFactory.create('email');
const smsNotifier = NotificationFactory.create('sms');
const pushNotifier = NotificationFactory.create('push');
emailNotifier.send('Your order has shipped!');
smsNotifier.send('OTP: 483920');
pushNotifier.send('New message received');

console.log('\n=== Observer Pattern ===');
const tracker = new OrderTracker();
createSubscribers(tracker);
tracker.placeOrder('ORD1001');
tracker.shipOrder('ORD1001');
