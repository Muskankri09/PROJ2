// singleton.js
// Singleton pattern: ensures a class has only one instance
// (commonly used for shared resources like DB connections, config, loggers).

class DatabaseConnection {
  constructor() {
    if (DatabaseConnection.instance) {
      return DatabaseConnection.instance;
    }
    this.connectionId = Math.floor(Math.random() * 10000);
    this.connectedAt = new Date().toISOString();
    DatabaseConnection.instance = this;
  }

  query(sql) {
    console.log(`[conn#${this.connectionId}] Running query: ${sql}`);
  }
}

module.exports = DatabaseConnection;
