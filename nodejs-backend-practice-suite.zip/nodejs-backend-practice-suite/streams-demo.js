// streams-demo.js
// Demonstrates Node.js Streams API for efficient I/O handling:
// a Readable stream generating data, piped through a Transform
// stream, and written out via a Writable stream -- without
// loading everything into memory at once.

const { Readable, Transform, Writable } = require('stream');

// 1. Readable stream: emits a sequence of numbers
class NumberStream extends Readable {
  constructor(max, options) {
    super(options);
    this.current = 1;
    this.max = max;
  }

  _read() {
    if (this.current > this.max) {
      this.push(null); // signal end of stream
      return;
    }
    this.push(`${this.current}\n`);
    this.current += 1;
  }
}

// 2. Transform stream: squares each number
class SquareTransform extends Transform {
  _transform(chunk, encoding, callback) {
    const num = parseInt(chunk.toString().trim(), 10);
    const squared = num * num;
    this.push(`${num}^2 = ${squared}\n`);
    callback();
  }
}

// 3. Writable stream: collects output (in a real app this could be a file/socket)
class LoggerWritable extends Writable {
  _write(chunk, encoding, callback) {
    process.stdout.write(`[stream output] ${chunk}`);
    callback();
  }
}

console.log('--- Streams demo: numbers 1-10 piped through square transform ---\n');

const numberStream = new NumberStream(10);
const squareTransform = new SquareTransform();
const logger = new LoggerWritable();

numberStream.pipe(squareTransform).pipe(logger);

logger.on('finish', () => {
  console.log('\nStream pipeline complete.');
});
